[ -f /usr/etc/zsh/fzf-config.zsh ] && source /usr/etc/zsh/fzf-config.zsh
