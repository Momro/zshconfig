# "ip a" in bunt!
alias ipa='ip -c a'
# easy poweroff
alias poweroff="systemctl poweroff"
# mein tastatur-layout umstellen
alias setdvoraklayout="setxkbmap -layout de -variant dvorak -option ctrl:nocaps"
# displayorientation umstellen
alias setdefaultdisplaylayout="xrandr --output VGA-0 --off --output DP-6 --off --output DP-5 --off --output DP-4 --mode 1920x1080 --pos 3840x0 --rotate normal --output DP-3 --off --output DP-2 --off --output DP-1 --mode 1920x1080 --pos 0x0 --rotate normal --output DP-0 --primary --mode 1920x1080 --pos 1920x0 --rotate normal"
# webdav starten
alias dovy='wsgidav -v --port=8000 --root=. --host=0.0.0.0 --no-config --server=cheroot'
# vpn starten
alias cv="connectvpn -cv"


alias cat=lolcat
alias catcat=/bin/cat
alias please=sudo
alias rhr="report-handler --makereadable"
alias rr="report-handler --makereadable"
alias mv2='f(){mv -i "$@";};f'
alias mv='mv -i'
alias python="/usr/bin/python3"
alias gitlog='git log --format="%n[Commit: %C(green)%h%Creset]  -  [Name: %C(green)%cn %C(reset)(PGP: %C(green)%G?%C(auto))]  -  [Date: %C(green)%ad%C(auto)]%d%n    %s" --date=format:"%Y-%m-%d %H:%M"'
alias harddisksize="sudo du -a / 2>/dev/null | sort -n -r | head -n "
alias fj="firejail"
# grep mit color und zeilennummer
alias grepc="grep -n --color"
# für Citrix Workspace
alias cws="/opt/Citrix/ICAClient/wfica" 
alias citrixWorkstation="/opt/Citrix/ICAClient/wfica" 
