function getBausteinDefaultWerte { 
	grep -i -r 'iffalse' -A 30 $1 | grep 'fi' -B 30 
}

function base64decode { 
	echo "$1" | base64 -d 
}

function openFinalizedReport {
	folder=$1
	file=$(sftp -P 1022 apfister@projects.syss.intern:$folder/Report <<< 'ls' 2>/dev/null | grep ".pdf")
	# remove trailing whitespaces
	file=$(echo $file | xargs)
	downloadFolder="/tmp/pdf"
	mkdir $downloadFolder
	sftp -P 1022 apfister@projects.syss.intern:$folder/Report/$file $downloadFolder/$file 2>/dev/null
	zathura $downloadFolder/$file
}
