function techqa() {
	#echo "dann machen wir mal eine techqa!"
	report=$1
	if [[ ! $report =~ "reports" ]]; then
		report="reports/"$report
	fi
	if [[ $report =~ ".git" ]]; then
		#report=$(sed 's/\.git//')
		report=$(echo "${report/\.git/}")
	fi
	rh -p silent 1 $report self 0 0 techqa
	checkout-report.sh $report
	#echo "ende"
}

function new-report.sh() {
	projektname=""
	# Falls new-report.sh aufgerufen wurde ohne Parameter, dann soll diese Funktion die Argumente abfragen
	if [[ "" == $1 ]] ; then
		echo "keine Argumente"
		read "kunde?Kundenname: " # zsh funktioniert anders als Bash beim Einlesen von Variablen
		appid=""
		modul=""
		# Spezialfall Daimler; hier müssen App-ID und Modul-Art angegeben werden
		if [[ "daimler" == $kunde ]] || [[ "Daimler" == $kunde ]] ; then
			read "appid?App-ID: "
			read "modul?Modul: "
		fi
		read "projekt?Projektname: "
		if [[ "daimler" == $kunde ]] || [[ "Daimler" == $kunde ]] ; then
			projektname="EPA-APP-"$appid"-"$modul"-"$projekt
			echo "Daimler-Projektname: "$projektname
		else
			projektname=$projekt
		fi
	fi

	# Danach passiert Standard-Magie von new-report.sh
    
	local new_report="$(whence -p "new-report.sh")"
    local vars
    local report_dir
    exec 4>&1 5>&2
   
	# hab vergessen, was das hier macht :-/
	if [[ "" == $1 ]] ; then
		vars="$( { ${new_report} $kunde $projektname 2>&5 1>&4; } 3>&1 )" 4>&1 5>&2
	else
		vars="$( { ${new_report} "$@" 2>&5 1>&4; } 3>&1 )" 4>&1 5>&2
	fi
    
	local r="$?"
    exec 4>&- 5>&-
    eval "${vars}"
	[[ -n "${report_dir}" && -d "${report_dir}" ]] && cd -- "${report_dir}"
	returnValue="$r"

	# Berechtigungen anpassen, z.B. für gemeinsame Projekte
	#read "permissions?Berechtigungen anpassen? (j/y/N) "
	#if [[ "j" == $permissions ]] || [[ "y" == $permissions ]] ; then
	#	mode=1
	#	if [[ "--local" == $1 ]] ; then
	#		dir="$2/$3"
	#	else
	#		dir="$1/$2"
	#	fi
	#	dir="reports/$dir"
	#	echo "Directory: "$dir
	#	read "user?Konto: "
	#	read "duration?Dauer: "
	#	if [[ "" == $duration ]] ; then
	#		duration=0
	#	fi
	#	read "rw?Read/Write? (y/j/N) "
	#	readwrite=""
	#	if [[ "y" == $rw ]] || [[ "j" == $rw ]] ; then
	#		readwrite=0
	#	else
	#		readwrite=1
	#	fi
	#	read "reason?Grund: "
	#	echo "rh --permissions $mode $dir $user $duration $readwrite \"$reason\""
	#	rh --permissions $mode $dir $user $duration $readwrite $reason
	#fi

    return "$returnValue"
}


function checkout-report.sh() {
	pfad=$1
	# langer pfad inkl. projects.syss.intern und so
	if [[ $(echo $pfad | cut -d "/" -f 1) = "projects.syss.intern:" ]]; then
		pfad=$(echo $pfad | cut -d "/" -f 4,5,6 | cut -d "." -f 1)
	# Du hast den Pfad ohne "reports" angegeben? Kein Problem!
	elif [[ $(echo $pfad | cut -d "/" -f 1) != "reports" ]] ; then
		pfad="reports/"$pfad
	fi

	# Zugangsrechte auslesen
	accessRights=$(ssh projects.syss.intern list-users $pfad)

	# AD user rausfinden aus Report Handler Config
	reportHandlerUserName=$(cat ~/.config/report-handler/config.yaml | grep "username" | cut -d "=" -f 2)

	# Checken, ob der AD user in den Access Rights drin ist
	if grep -q $reportHandlerUserName <<< $accessRights ; then
		true
	else
		echo "You have no access rights"
		read "grantRights?Do you want to give yourself access? (Y/J/n) " 

		if [[ "n" != $grantRights ]] ; then
			echo "Ok! let's go"
			rh --no-resume --permissions interactive 1 $pfad self
		else
			echo "Ok, then not!"
		fi
	fi

	# hier passiert so Standard-Magie von checkout-report.sh

    local checkout_report="$(whence -p "checkout-report.sh")"
    local vars
    local report_dir
    exec 4>&1 5>&2
    vars="$( { ${checkout_report} "$@" 2>&5 1>&4; } 3>&1 )" 4>&1 5>&2
    local r="$?"
    exec 4>&- 5>&-
    eval "${vars}"
	# das hier wechselt glaub per cd in das Verzeichnis
    [[ -n "${report_dir}" && -d "${report_dir}" ]] && cd -- "${report_dir}"
    return "$r"
}

