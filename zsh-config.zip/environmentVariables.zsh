export LESS="-iXr"

# config folder
XDG_CONFIG_HOME=~/.config/

export -U PATH="$PATH:${HOME}/texmf/tex/latex/reportstyle/scripts:$PATH"
export -U PATH="$PATH:${HOME}/texmf/tex/latex/syss-report/scripts:$PATH"
export -U PATH="$PATH:${HOME}/texmf/tex/latex/syss/scripts"
export -U PATH="$PATH:/usr/local/texlive/2021/bin/x86_64-linux"

if [ -f "$HOME/.local/bin/gitup" ] ; then
	PATH="$HOME/.local/bin/:$PATH"                                                       
fi  
export SYSSREPDIR="$HOME"
#export TEXMFDIST=/home/skuta/.texlive2018/texmf-dist
export TEXMFHOME=/home/skuta/texmf
export TEXMFHOME=/home/pfister/texmf

export consultant="apfister"
export curlsocks="-xsocks5h://localhost:8090"
export curlburp="-xhttp://localhost:8080"

# mal schauen, ob das funktioniert
export SUDO_EDITOR="vim"
export env_editor="vim"

# syss report style
#PATH=$PATH":${HOME}/texmf/tex/latex/syss-report/scripts"

# autojump
[[ -s /home/pfister/.autojump/etc/profile.d/autojump.sh ]] && source /home/pfister/.autojump/etc/profile.d/autojump.sh
autoload -U compinit && compinit -u

# Go
#export GOROOT=/usr/lib/go
#export GOPATH=$HOME/go
#export PATH=$PATH:$GOROOT/bin:$GOPATH/bin
